# git-lesson-repository
An example repository for the command line workshop in tools and basics module.

For the problems see the workshop: https://github.com/greenfox-academy/teaching-materials/edit/master/workshop/command-line
